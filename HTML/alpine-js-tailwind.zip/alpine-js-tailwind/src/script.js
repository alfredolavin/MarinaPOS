









function as_currency(numero) {
  const agrupado = numero.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  const padded = agrupado.padStart(8, "\u00A0");
  return "$" + padded;
}

function hilite(e) {
  var str = codeIn.value;
  const orig = str;
  changed = () => orig != str;

  str = str.replace(
    /^(\s*)(\d+)(\s*)(X)(\s*)(\w+)(\s*)(\$)(\s*)(\d+)(\s*)$/gim,
    "$1<span class='cantidad'>$2</span>$3<span class='X'>$4</span>$5<span class='codigo'>$6</span>$7<span class='signo_peso'>$8</span>$9<span class='precio'>$10</span>$11"
  );

  if (changed()) {
    code.innerHTML = str;
    return;
  }

  str = str.replace(
    /^(\s*)(\d+)(\s*)(X)(\s*)(\w+)(\s*)/gim,
    "$1<span class='cantidad'>$2</span>$3<span class='X'>$4</span>$5<span class='codigo'>$6</span>$7"
  );

  if (changed()) {
    code.innerHTML = str;
    return;
  }

  str = str.replace(
    /^\/(\w+)/gim,
    "<span class='slash'>/</span><span class='comando'>$1</span>"
  );

  if (changed()) {
    code.innerHTML = str;
    return;
  }

  code.innerHTML = str;
}
hilite();
codeIn.oninput = hilite;


var veces_escape_presionado = 0;
var ultima_vez_escape_presionado = 0;
function maneja_escape(lista) {
  if (new Date().getTime() - ultima_vez_escape_presionado < 400) {
    if (veces_escape_presionado++ == 3) {
      lista.length = 0;
      veces_escape_presionado = 0;
    }
  } else {
    veces_escape_presionado = 0;
  }
  ultima_vez_escape_presionado = new Date().getTime();
}
