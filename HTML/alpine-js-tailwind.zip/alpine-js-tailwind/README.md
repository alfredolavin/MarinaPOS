# Alpine.js + Tailwind 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Farmacia-Outletfarma/pen/GRbNmdv](https://codepen.io/Farmacia-Outletfarma/pen/GRbNmdv).

